<template>
  <div class="flex h-screen">
    <span class="flex m-auto align-center items-center text-6xl">🍑</span>
  </div>
</template>

<script>
export default {
  name: "Splashscreen"
}
</script>