// Name file example.spec.js

/*import InfoWindowMobile from '@/components/InfoWindowMobile'
import { mount } from '@vue/test-utils'

describe('InfoWindowMobile.vue default', () => {
  it('Check default variable', () => {
    expect(typeof InfoWindowMobile.data).toBe('function')
    const defaultData = InfoWindowMobile.data()
    expect(defaultData.infowindow).toBe(true)
    expect(defaultData.isHidden).toBe(true)
  })
})

describe('showHideInfo function', () => {
  const wrapper = mount(InfoWindowMobile)
  it('Test showHideInfo', () => {
    let display = wrapper.vm.isHidden
    wrapper.vm.showHideInfos()
    expect(wrapper.vm.isHidden).toBe(!display)
  })
})*/
